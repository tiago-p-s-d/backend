-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05/01/2024 às 21:15
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_tarefas`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tarefa`
--

CREATE TABLE `tarefa` (
  `id` int(11) NOT NULL,
  `titulo` varchar(300) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tarefa`
--

INSERT INTO `tarefa` (`id`, `titulo`, `descricao`) VALUES
(1, 'as tranças do rei careca', 'ele é carecasso mlk'),
(2, 'harry pottewr e a pedra filosofal', 'ele é o harry potter mlk'),
(3, 'amongus', 'SASAS');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbaluno`
--

CREATE TABLE `tbaluno` (
  `id` int(11) NOT NULL,
  `nome_aluno` varchar(100) NOT NULL,
  `nome_casa` varchar(50) NOT NULL,
  `nome_patrono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbaluno`
--

INSERT INTO `tbaluno` (`id`, `nome_aluno`, `nome_casa`, `nome_patrono`) VALUES
(1, 'Heloysa Raiane Leão Wanderley', 'lufa lufa', 'golden retriever'),
(2, 'Tiago Peixoto da Silva Dantas', 'corvinal', 'mamba negra'),
(3, 'Tom Hiddle', 'sonserina', 'parry o ornintorrinco'),
(5, 'hermione teste procopio', 'lufa lufa', 'lontraaaaaaaaaaaaa'),
(6, ' Arthur Malfoy', 'sonserina', 'pato donald'),
(7, 'clara vitoria', 'lufa lufa', 'ovelha fofa');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_patrono`
--

CREATE TABLE `tb_patrono` (
  `id` int(11) NOT NULL,
  `nome_pat` varchar(50) NOT NULL,
  `desc_pat` varchar(200) NOT NULL,
  `nome_especie` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_patrono`
--

INSERT INTO `tb_patrono` (`id`, `nome_pat`, `desc_pat`, `nome_especie`) VALUES
(1, 'Mamba Negra Albina', 'esse e o patrono da famÃ­lia peixoto', 'mamba negra'),
(2, 'Cachorro Golden Retriever', 'esse e o patrono da famÃ­lia Raiane', 'golden retriever'),
(3, 'Coruja Branca', 'esse e o patrono da famÃ­lia Grace', 'coruja branca'),
(4, 'Urso sem curso ', 'urso sem curso legal ', 'urso polar'),
(5, 'Pipis', 'Ave fofa', 'gavião'),
(6, 'Osvaldo', 'Osvaldo Ã© um ganso dos montes alpinos treiou durante 200 anos, para ser formado em mais de 2000 formas de meter a porrada.', 'ganso');

-- --------------------------------------------------------

--
-- Estrutura para tabela `teste`
--

CREATE TABLE `teste` (
  `id` int(11) NOT NULL,
  `titulo` varchar(300) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `teste`
--

INSERT INTO `teste` (`id`, `titulo`, `descricao`) VALUES
(1, 'esse eh o teste supremo', 'essa eh a descricao suprema');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tarefa`
--
ALTER TABLE `tarefa`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tbaluno`
--
ALTER TABLE `tbaluno`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tb_patrono`
--
ALTER TABLE `tb_patrono`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `teste`
--
ALTER TABLE `teste`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tarefa`
--
ALTER TABLE `tarefa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tbaluno`
--
ALTER TABLE `tbaluno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tb_patrono`
--
ALTER TABLE `tb_patrono`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `teste`
--
ALTER TABLE `teste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
